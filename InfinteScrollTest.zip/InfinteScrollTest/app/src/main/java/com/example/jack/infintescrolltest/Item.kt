package com.example.jack.infintescrolltest

data class Item(val id: Int, val name: String)