import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import androidx.paging.PagedList
import com.example.jack.infintescrolltest.Item
import com.example.jack.infintescrolltest.Resource

class ItemViewModel() : ViewModel() {

    val beforeResource: LiveData<Resource<Any>>? = null
    val afteresource: LiveData<Resource<Any>>? = null

    fun showItemsForPosition(position: Int): LiveData<List<Item>> {
        val liveData = MutableLiveData<List<Item>>()
        liveData.value = listOf(Item(1, "One"), Item(2, "Two"))
        return liveData
    }
}